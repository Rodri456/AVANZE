import { Router } from "express";

import { getAllVacantes, getBuscarById, getBuscarPorTitulo, getBuscarPorUbicacion, getBuscarPorModalidad, getBuscarPorTipoContrato,crearVacante,actualizarVacante,eliminarVacante} from '../services/vacantesServices.js';

const router = Router();

router.get('/', getAllVacantes);

router.get('/buscarPorId/:id_vacante', async (req, res) => {
    const { id_vacante } = req.params;
    try {
        const resultados = await getBuscarById(id_vacante);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/buscarPorTitulo/:titulo', async (req, res) => {
    const { titulo } = req.params;
    try {
        const resultados = await getBuscarPorTitulo(titulo);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/buscarPorUbicacion/:ubicacion', async (req, res) => {
    const { ubicacion } = req.params;
    try {
        const resultados = await getBuscarPorUbicacion(ubicacion);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/buscarPorModalidad/:modalidad', async (req, res) => {
    const { modalidad } = req.params;
    try {
        const resultados = await getBuscarPorModalidad(modalidad);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Buscar por tipo de contrato
router.get('/buscarPorTipoContrato/:tipo_contrato', async (req, res) => {
    const { tipo_contrato } = req.params;
    try {
        const resultados = await getBuscarPorTipoContrato(tipo_contrato);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', crearVacante);

router.put('/:id_vacante', actualizarVacante);

router.delete('/:id_vacante', eliminarVacante);

export default router;