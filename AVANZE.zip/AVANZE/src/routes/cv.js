import { Router } from "express";

import { getAllCv,getCVByTelefono,getCVByUbicacion,crearCV, actualizarCV, eliminarCV  } from '../services/cvServices.js';

const router = Router();

router.get('/', getAllCv);



router.get('/buscarPorTelefono/:telefono', getCVByTelefono);


router.get('/buscarPorUbicacion/:ubicacion', getCVByUbicacion);

router.post('/', crearCV);

router.put('/:id_cv', actualizarCV);


router.delete('/:id_cv', eliminarCV);

export default router;