import { Router } from "express";

import { getAllEmpresas,getEmpresaByNombre,getEmpresaByUbicacion, getEmpresaByCalificacion,crearEmpresa,actualizarEmpresa,eliminarEmpresa } from '../services/empresasServices.js';

const router = Router();

router.get('/', getAllEmpresas);

router.get('/buscarPorNombre/:nombre', getEmpresaByNombre);

router.get('/buscarPorUbicacion/:ubicacion', getEmpresaByUbicacion);

router.get('/buscarPorCalificacion/:calificacion', getEmpresaByCalificacion);

router.post('/', crearEmpresa);

router.put('/:id_empresa', actualizarEmpresa);

router.delete('/:id_empresa', eliminarEmpresa);

export default router;