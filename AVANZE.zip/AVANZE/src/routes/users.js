import { Router } from "express";

import { getAllUsers,getUserByCorreo,getBuscarNombre,getBuscarById,crearUser,actualizarUser,eliminarUser } from '../services/userServices.js';

const router = Router();

router.get('/', getAllUsers);

router.get('/buscarPorCorreo/:correo', getUserByCorreo);

router.get('/buscarPorNombre/:nombre', async (req, res) => {
    const { nombre } = req.params;
    try {
        const AllUsersByName = await getBuscarNombre(nombre);
        res.json(AllUsersByName);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }   
});

router.get('/buscarPorId/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const resultado = await getBuscarById(id);
        res.json(resultado);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', crearUser);

router.put('/:id', actualizarUser);

router.delete('/:id', eliminarUser);

export default router;