import { Router } from "express";

import { getAllForos,getForosByTitulo,getForosByFecha,crearForo, actualizarForo, eliminarForo } from '../services/forosServices.js';

const router = Router();

router.get('/', getAllForos);

router.get('/buscarPorTitulo/:titulo', getForosByTitulo);

router.get('/buscarPorFecha/:fecha', getForosByFecha);

router.post('/', crearForo);

router.put('/:id_foro', actualizarForo);

router.delete('/:id_foro', eliminarForo);

export default router;