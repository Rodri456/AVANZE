import { Router } from "express";

import { getAllComentarios,getComentariosByUsuario,crearComentario, actualizarComentario, borrarComentario } from '../services/comentariosServices.js';

const router = Router();

router.get('/', getAllComentarios);

router.get('/buscarPorUsuario/:id_usuario', getComentariosByUsuario);

//metodos

router.post('/', crearComentario);

router.put('/:id_comentario', actualizarComentario);

router.delete('/:id_comentario', borrarComentario);

export default router;