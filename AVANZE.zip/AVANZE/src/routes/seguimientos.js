import { Router } from "express";

import { getAllSeguimientos, getSeguimientoById, crearSeguimiento, actualizarSeguimiento,eliminarSeguimiento } from '../services/seguimientosServices.js';

const router = Router();

router.get('/', getAllSeguimientos);

router.get('/buscarPorId/:id_seguimiento', getSeguimientoById);
router.post('/', crearSeguimiento);
router.put('/:id_seguimiento', actualizarSeguimiento);
router.delete('/:id_seguimiento', eliminarSeguimiento);

export default router;