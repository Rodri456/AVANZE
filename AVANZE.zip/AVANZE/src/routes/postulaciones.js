import { Router } from "express";

import { getAllPostulaciones, getPostulacionById, crearPostulacion, actualizarPostulacion,eliminarPostulacion } from '../services/postulacionesServices.js';

const router = Router();

router.get('/', getAllPostulaciones);

router.get('/buscarPorId/:id_postulacion', getPostulacionById);

router.post('/', crearPostulacion);

router.put('/:id_postulacion', actualizarPostulacion);

router.delete('/:id_postulacion', eliminarPostulacion);

export default router;