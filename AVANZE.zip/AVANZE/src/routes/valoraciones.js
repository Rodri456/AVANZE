import { Router } from "express";

import { getAllValoraciones,getBuscarByIdUsuario,getBuscarByIdEmpresa,crearValoracion,actualizarValoracion,eliminarValoracion } from '../services/valoracionesServices.js';

const router = Router();

router.get('/', getAllValoraciones);

router.get('/buscarPorIdUsuario/:id_usuario', async (req, res) => {
    const { id_usuario } = req.params;
    try {
        const resultados = await getBuscarByIdUsuario(id_usuario);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


router.get('/buscarPorIdEmpresa/:id_empresa', async (req, res) => {
    const { id_empresa } = req.params;
    try {
        const resultados = await getBuscarByIdEmpresa(id_empresa);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', crearValoracion);

router.put('/:id_valoracion', actualizarValoracion);

router.delete('/:id_valoracion', eliminarValoracion);

export default router;