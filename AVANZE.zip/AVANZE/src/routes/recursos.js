import { Router } from "express";

import { getAllRecursos,getBuscarPorTitulo,crearRecurso,actualizarRecurso,eliminarRecurso } from '../services/recursosServices.js';

const router = Router();

router.get('/', getAllRecursos);

router.post('/', crearRecurso);

router.put('/:id_recurso', actualizarRecurso);

router.delete('/:id_recurso', eliminarRecurso);

router.get('/buscarPorTitulo/:titulo', async (req, res) => {
    const { titulo } = req.params;
    try {
        const resultados = await getBuscarPorTitulo(titulo);
        res.json(resultados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;