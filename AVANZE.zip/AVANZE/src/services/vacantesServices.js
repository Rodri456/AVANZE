import { pool } from '../db.js';

export const getAllVacantes = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM vacantes');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getBuscarPorTitulo = async (titulo) => {
    const buscar = `%${titulo}%`;
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM vacantes v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.titulo ILIKE $1 AND v.activa = true
         ORDER BY v.fecha_publicacion DESC`,
        [buscar]
    );
    return result.rows;
};

export const getBuscarPorUbicacion = async (ubicacion) => {
    const buscar = `%${ubicacion}%`;
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM vacantes v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.ubicacion ILIKE $1 AND v.activa = true
         ORDER BY v.fecha_publicacion DESC`,
        [buscar]
    );
    return result.rows;
};

export const getBuscarPorModalidad = async (modalidad) => {
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM vacantes v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.modalidad = $1 AND v.activa = true
         ORDER BY v.fecha_publicacion DESC`,
        [modalidad]
    );
    return result.rows;
};

export const getBuscarPorTipoContrato = async (tipo_contrato) => {
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM vacantes v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.tipo_contrato = $1 AND v.activa = true
         ORDER BY v.fecha_publicacion DESC`,
        [tipo_contrato]
    );
    return result.rows;
};

export const getBuscarById = async (id_vacante) => {
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM vacantes v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.id_vacante = $1`,
        [id_vacante]
    );
    return result.rows;
};

export const crearVacante = async (req, res) => {
    const { id_empresa, titulo, descripcion, requisitos, ubicacion, salario_oferta, tipo_contrato, modalidad, fecha_limite, activa } = req.body;
    
    if (!id_empresa || !titulo) {
        return res.status(400).json({ error: 'id_empresa y titulo son requeridos' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO vacantes (id_empresa, titulo, descripcion, requisitos, ubicacion, salario_oferta, tipo_contrato, modalidad, fecha_publicacion, fecha_limite, activa)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_TIMESTAMP, $9, $10)
            RETURNING *
        `, [id_empresa, titulo, descripcion, requisitos, ubicacion, salario_oferta, tipo_contrato, modalidad, fecha_limite, activa !== undefined ? activa : true]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarVacante = async (req, res) => {
    const { id_vacante } = req.params;
    const { id_empresa, titulo, descripcion, requisitos, ubicacion, salario_oferta, tipo_contrato, modalidad, fecha_limite, activa } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE vacantes 
            SET id_empresa = COALESCE($1, id_empresa),
                titulo = COALESCE($2, titulo),
                descripcion = COALESCE($3, descripcion),
                requisitos = COALESCE($4, requisitos),
                ubicacion = COALESCE($5, ubicacion),
                salario_oferta = COALESCE($6, salario_oferta),
                tipo_contrato = COALESCE($7, tipo_contrato),
                modalidad = COALESCE($8, modalidad),
                fecha_limite = COALESCE($9, fecha_limite),
                activa = COALESCE($10, activa)
            WHERE id_vacante = $11
            RETURNING *
        `, [id_empresa, titulo, descripcion, requisitos, ubicacion, salario_oferta, tipo_contrato, modalidad, fecha_limite, activa, id_vacante]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Vacante no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarVacante = async (req, res) => {
    const { id_vacante } = req.params;
    
    try {
        const result = await pool.query(
            'DELETE FROM vacantes WHERE id_vacante = $1 RETURNING *',
            [id_vacante]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Vacante no encontrada' });
        }
        res.json({ message: 'Vacante eliminada exitosamente', vacante: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};