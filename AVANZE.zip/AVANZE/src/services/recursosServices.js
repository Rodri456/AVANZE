import { pool } from '../db.js';

export const getAllRecursos = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM recursos');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};


export const getBuscarPorTitulo = async (titulo) => {
    const buscar = `%${titulo}%`;
    const result = await pool.query(
        "SELECT * FROM recursos WHERE titulo ILIKE $1 ORDER BY fecha_publicacion DESC",
        [buscar]
    );
    return result.rows;
};

export const crearRecurso = async (req, res) => {
    const { titulo, contenido, tipo, url, fecha_publicacion } = req.body;
    
    if (!titulo) {
        return res.status(400).json({ error: 'El título es requerido' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO recursos (titulo, contenido, tipo, url, fecha_publicacion)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `, [titulo, contenido, tipo, url, fecha_publicacion || new Date()]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarRecurso = async (req, res) => {
    const { id_recurso } = req.params;
    const { titulo, contenido, tipo, url, fecha_publicacion } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE recursos 
            SET titulo = COALESCE($1, titulo),
                contenido = COALESCE($2, contenido),
                tipo = COALESCE($3, tipo),
                url = COALESCE($4, url),
                fecha_publicacion = COALESCE($5, fecha_publicacion)
            WHERE id_recurso = $6
            RETURNING *
        `, [titulo, contenido, tipo, url, fecha_publicacion, id_recurso]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Recurso no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarRecurso = async (req, res) => {
    const { id_recurso } = req.params;
    
    try {
        const result = await pool.query('DELETE FROM recursos WHERE id_recurso = $1 RETURNING *', [id_recurso]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Recurso no encontrado' });
        }
        res.json({ message: 'Recurso eliminado exitosamente', recurso: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};