import { pool } from '../db.js';

export const getAllSeguimientos = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM seguimientos');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getSeguimientoById = async (req, res) => {
    const { id_seguimiento } = req.params;
    try {
        const result = await pool.query('SELECT * FROM seguimientos WHERE id_seguimiento = $1', [id_seguimiento]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Seguimiento no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const crearSeguimiento = async (req, res) => {
    const { id_postulacion, id_gestor, mensaje, fecha_seguimiento } = req.body;
    
    if (!id_postulacion) {
        return res.status(400).json({ error: 'id_postulacion es requerido' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO seguimientos (id_postulacion, id_gestor, mensaje, fecha_seguimiento)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `, [id_postulacion, id_gestor, mensaje, fecha_seguimiento || new Date()]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarSeguimiento = async (req, res) => {
    const { id_seguimiento } = req.params;
    const { id_postulacion, id_gestor, mensaje, fecha_seguimiento } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE seguimientos 
            SET id_postulacion = COALESCE($1, id_postulacion),
                id_gestor = COALESCE($2, id_gestor),
                mensaje = COALESCE($3, mensaje),
                fecha_seguimiento = COALESCE($4, fecha_seguimiento)
            WHERE id_seguimiento = $5
            RETURNING *
        `, [id_postulacion, id_gestor, mensaje, fecha_seguimiento, id_seguimiento]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Seguimiento no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarSeguimiento = async (req, res) => {
    const { id_seguimiento } = req.params;
    
    try {
        const result = await pool.query('DELETE FROM seguimientos WHERE id_seguimiento = $1 RETURNING *', [id_seguimiento]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Seguimiento no encontrado' });
        }
        res.json({ message: 'Seguimiento eliminado exitosamente', seguimiento: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};