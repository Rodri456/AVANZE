import { pool } from '../db.js';

export const getAllValoraciones = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM valoraciones_empresa');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getBuscarByIdUsuario = async (id_usuario) => {
    const result = await pool.query(
        `SELECT v.*, e.nombre as empresa_nombre 
         FROM valoraciones_empresa v
         LEFT JOIN empresas e ON v.id_empresa = e.id_empresa
         WHERE v.id_usuario = $1
         ORDER BY v.fecha_valoracion DESC`,
        [id_usuario]
    );
    return result.rows;
};

export const getBuscarByIdEmpresa = async (id_empresa) => {
    const result = await pool.query(
        `SELECT v.*, u.nombre as usuario_nombre 
         FROM valoraciones_empresa v
         LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario
         WHERE v.id_empresa = $1
         ORDER BY v.fecha_valoracion DESC`,
        [id_empresa]
    );
    return result.rows;
};

export const crearValoracion = async (req, res) => {
    const { id_usuario, id_empresa, calificacion, comentario, fecha_valoracion } = req.body;
    
    if (!id_usuario || !id_empresa || !calificacion) {
        return res.status(400).json({ error: 'id_usuario, id_empresa y calificacion son requeridos' });
    }
    
    if (calificacion < 1 || calificacion > 5) {
        return res.status(400).json({ error: 'La calificación debe estar entre 1 y 5' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO valoraciones_empresa (id_usuario, id_empresa, calificacion, comentario, fecha_valoracion)
            VALUES ($1, $2, $3, $4, $5)
            ON CONFLICT (id_usuario, id_empresa) 
            DO UPDATE SET calificacion = EXCLUDED.calificacion, comentario = EXCLUDED.comentario, fecha_valoracion = EXCLUDED.fecha_valoracion
            RETURNING *
        `, [id_usuario, id_empresa, calificacion, comentario, fecha_valoracion || new Date()]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarValoracion = async (req, res) => {
    const { id_valoracion } = req.params;
    const { calificacion, comentario, fecha_valoracion } = req.body;
    
    if (calificacion && (calificacion < 1 || calificacion > 5)) {
        return res.status(400).json({ error: 'La calificación debe estar entre 1 y 5' });
    }
    
    try {
        const result = await pool.query(`
            UPDATE valoraciones_empresa 
            SET calificacion = COALESCE($1, calificacion),
                comentario = COALESCE($2, comentario),
                fecha_valoracion = COALESCE($3, fecha_valoracion)
            WHERE id_valoracion = $4
            RETURNING *
        `, [calificacion, comentario, fecha_valoracion, id_valoracion]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Valoración no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarValoracion = async (req, res) => {
    const { id_valoracion } = req.params;
    
    try {
        const result = await pool.query(
            'DELETE FROM valoraciones_empresa WHERE id_valoracion = $1 RETURNING *',
            [id_valoracion]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Valoración no encontrada' });
        }
        res.json({ message: 'Valoración eliminada exitosamente', valoracion: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};