import { pool } from '../db.js';

export const getAllEmpresas = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM empresas');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getEmpresaByNombre = async (req, res) => {
    const { nombre } = req.params;
    try {
        const buscarNombre = `%${nombre}%`;
        const result = await pool.query(
            'SELECT * FROM empresas WHERE nombre ILIKE $1 ORDER BY nombre',
            [buscarNombre]
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const getEmpresaByUbicacion = async (ubicacion) => {
    const buscar = `%${ubicacion}%`;
    const result = await pool.query(
        'SELECT * FROM empresas WHERE ubicacion ILIKE $1 ORDER BY nombre',
        [buscar]
    );
    return result.rows;
};

export const getEmpresaByCalificacion = async (calificacion) => {
    const result = await pool.query(
        'SELECT * FROM empresas WHERE calificacion_promedio >= $1 ORDER BY calificacion_promedio DESC',
        [calificacion]
    );
    return result.rows;
};


export const crearEmpresa = async (req, res) => {
    const { nombre, descripcion, ubicacion, sitio_web, calificacion_promedio } = req.body;
    
    if (!nombre) {
        return res.status(400).json({ error: 'El nombre de la empresa es requerido' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO empresas (nombre, descripcion, ubicacion, sitio_web, calificacion_promedio, fecha_creacion)
            VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
            RETURNING *
        `, [nombre, descripcion, ubicacion, sitio_web, calificacion_promedio || 0]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


export const actualizarEmpresa = async (req, res) => {
    const { id_empresa } = req.params;
    const { nombre, descripcion, ubicacion, sitio_web, calificacion_promedio } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE empresas 
            SET nombre = COALESCE($1, nombre),
                descripcion = COALESCE($2, descripcion),
                ubicacion = COALESCE($3, ubicacion),
                sitio_web = COALESCE($4, sitio_web),
                calificacion_promedio = COALESCE($5, calificacion_promedio)
            WHERE id_empresa = $6
            RETURNING *
        `, [nombre, descripcion, ubicacion, sitio_web, calificacion_promedio, id_empresa]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Empresa no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarEmpresa = async (req, res) => {
    const { id_empresa } = req.params;
    
    try {
        const result = await pool.query(
            'DELETE FROM empresas WHERE id_empresa = $1 RETURNING *',
            [id_empresa]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Empresa no encontrada' });
        }
        res.json({ message: 'Empresa eliminada exitosamente', empresa: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};