import { pool } from '../db.js';

export const getAllComentarios = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM comentarios_foro');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getComentariosByUsuario = async (req, res) => {
    const { id_usuario } = req.params;
    try {
        const result = await pool.query(`
            SELECT c.*, f.titulo as foro_titulo 
            FROM comentarios_foro c
            LEFT JOIN foros f ON c.id_foro = f.id_foro
            WHERE c.id_usuario = $1
            ORDER BY c.fecha_comentario DESC
        `, [id_usuario]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

//metodos

export const crearComentario = async (req, res) => {
    const { id_foro, id_usuario, mensaje } = req.body;
    try {
        const result = await pool.query(`
            INSERT INTO comentarios_foro (id_foro, id_usuario, mensaje, fecha_comentario)
            VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
            RETURNING *
        `, [id_foro, id_usuario || null, mensaje]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarComentario = async (req, res) => {
    const { id_comentario } = req.params;
    const { mensaje } = req.body;
    
    if (!mensaje) {
        return res.status(400).json({ error: 'El mensaje es requerido' });
    }
    
    try {
        const result = await pool.query(`
            UPDATE comentarios_foro 
            SET mensaje = $1, fecha_comentario = CURRENT_TIMESTAMP
            WHERE id_comentario = $2
            RETURNING *
        `, [mensaje, id_comentario]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Comentario no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const borrarComentario = async (req, res) => {
    const { id_comentario } = req.params;
    try {
        const result = await pool.query(`
            DELETE FROM comentarios_foro 
            WHERE id_comentario = $1
            RETURNING *
        `, [id_comentario]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Comentario no encontrado' });
        }
        res.json({ message: 'Comentario eliminado exitosamente', comentario: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

