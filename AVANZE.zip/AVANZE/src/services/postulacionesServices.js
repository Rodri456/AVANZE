import { pool } from '../db.js';

export const getAllPostulaciones = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM postulaciones');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getPostulacionById = async (req, res) => {
    const { id_postulacion } = req.params;
    try {
        const result = await pool.query('SELECT * FROM postulaciones WHERE id_postulacion = $1', [id_postulacion]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Postulación no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const crearPostulacion = async (req, res) => {
    const { id_vacante, id_usuario, estado, fecha_postulacion } = req.body;
    
    try {
        const result = await pool.query(`
            INSERT INTO postulaciones (id_vacante, id_usuario, estado, fecha_postulacion)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `, [id_vacante, id_usuario, estado, fecha_postulacion || new Date()]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarPostulacion = async (req, res) => {
    const { id_postulacion } = req.params;
    const { id_vacante, id_usuario, estado, fecha_postulacion } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE postulaciones 
            SET id_vacante = COALESCE($1, id_vacante),
                id_usuario = COALESCE($2, id_usuario),
                estado = COALESCE($3, estado),
                fecha_postulacion = COALESCE($4, fecha_postulacion)
            WHERE id_postulacion = $5
            RETURNING *
        `, [id_vacante, id_usuario, estado, fecha_postulacion, id_postulacion]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Postulación no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarPostulacion = async (req, res) => {
    const { id_postulacion } = req.params;
    
    try {
        const result = await pool.query('DELETE FROM postulaciones WHERE id_postulacion = $1 RETURNING *', [id_postulacion]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Postulación no encontrada' });
        }
        res.json({ message: 'Postulación eliminada exitosamente', postulacion: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};