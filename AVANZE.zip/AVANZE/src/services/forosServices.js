import { pool } from '../db.js';

export const getAllForos = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM foros');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getForosByTitulo = async (req, res) => {
    const { titulo } = req.params;
    try {
        const buscarTitulo = `%${titulo}%`;
        const result = await pool.query(`
            SELECT f.*, u.nombre as usuario_nombre 
            FROM foros f
            LEFT JOIN usuarios u ON f.id_usuario = u.id_usuario
            WHERE f.titulo ILIKE $1
            ORDER BY f.fecha_creacion DESC
        `, [buscarTitulo]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const getForosByFecha = async (req, res) => {
    const { fecha } = req.params;
    try {
        const result = await pool.query(`
            SELECT f.*, u.nombre as usuario_nombre 
            FROM foros f
            LEFT JOIN usuarios u ON f.id_usuario = u.id_usuario
            WHERE DATE(f.fecha_creacion) = $1
            ORDER BY f.fecha_creacion DESC
        `, [fecha]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const crearForo = async (req, res) => {
    const { titulo, contenido, id_usuario, cerrado } = req.body;
    
    if (!titulo) {
        return res.status(400).json({ error: 'El título es requerido' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO foros (titulo, contenido, id_usuario, fecha_creacion, cerrado)
            VALUES ($1, $2, $3, CURRENT_TIMESTAMP, $4)
            RETURNING *
        `, [titulo, contenido, id_usuario || null, cerrado || false]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarForo = async (req, res) => {
    const { id_foro } = req.params;
    const { titulo, contenido, cerrado } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE foros 
            SET titulo = COALESCE($1, titulo),
                contenido = COALESCE($2, contenido),
                cerrado = COALESCE($3, cerrado)
            WHERE id_foro = $4
            RETURNING *
        `, [titulo, contenido, cerrado, id_foro]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Foro no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarForo = async (req, res) => {
    const { id_foro } = req.params;
    
    try {
        const result = await pool.query(
            'DELETE FROM foros WHERE id_foro = $1 RETURNING *',
            [id_foro]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Foro no encontrado' });
        }
        res.json({ message: 'Foro eliminado exitosamente', foro: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};