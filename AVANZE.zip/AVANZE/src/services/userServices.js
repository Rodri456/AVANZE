import { pool } from '../db.js';

export const getAllUsers = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM usuarios');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getUserByCorreo = async (req, res) => {
    const { correo } = req.params;
    try {
        const result = await pool.query('SELECT * FROM usuarios WHERE correo = $1', [correo]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const getBuscarNombre = async (nombre) => {
    const buscar = `%${nombre}%`;
    const result = await pool.query(
        "SELECT * FROM usuarios WHERE nombre like $1",[buscar]
    );
    return result.rows;
};

export const getBuscarById = async (id_usuario) => {
    const result = await pool.query(
        "SELECT * FROM usuarios WHERE id_usuario = $1",
        [id_usuario]
    );
    return result.rows;
};

export const crearUser = async (req, res) => {
    const { nombre, correo, password, rol } = req.body;
    
    if (!nombre || !correo) {
        return res.status(400).json({ error: 'Nombre y correo son requeridos' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO usuarios (nombre, correo, password, rol)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `, [nombre, correo, password, rol || 'usuario']);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarUser = async (req, res) => {
    const { id } = req.params;
    const { nombre, correo, password, rol } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE usuarios 
            SET nombre = COALESCE($1, nombre),
                correo = COALESCE($2, correo),
                password = COALESCE($3, password),
                rol = COALESCE($4, rol)
            WHERE id_usuario = $5
            RETURNING *
        `, [nombre, correo, password, rol, id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarUser = async (req, res) => {
    const { id } = req.params;
    
    try {
        const result = await pool.query(
            'DELETE FROM usuarios WHERE id_usuario = $1 RETURNING *',
            [id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }
        res.json({ message: 'Usuario eliminado exitosamente', usuario: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};