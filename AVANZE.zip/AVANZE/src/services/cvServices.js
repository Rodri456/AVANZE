import { pool } from '../db.js';

export const getAllCv = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM cv');
        
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message});
    }
};

export const getCVByTelefono = async (req, res) => {
    const { telefono } = req.params;
    try {
        const result = await pool.query(
            'SELECT * FROM cv WHERE telefono = $1',
            [telefono]
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const getCVByUbicacion = async (req, res) => {
    const { ubicacion } = req.params;
    try {
        const buscarUbicacion = `%${ubicacion}%`;
        const result = await pool.query(
            'SELECT * FROM cv WHERE ubicacion ILIKE $1',
            [buscarUbicacion]
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};






export const crearCV = async (req, res) => {
    const { id_usuario, datos_personales, experiencia_laboral, formacion_academica, habilidades, ubicacion, telefono } = req.body;
    
    if (!id_usuario) {
        return res.status(400).json({ error: 'id_usuario es requerido' });
    }
    
    try {
        const result = await pool.query(`
            INSERT INTO cv (id_usuario, datos_personales, experiencia_laboral, formacion_academica, habilidades, ubicacion, telefono, fecha_actualizacion)
            VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)
            RETURNING *
        `, [id_usuario, datos_personales, experiencia_laboral, formacion_academica, habilidades, ubicacion, telefono]);
        
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const actualizarCV = async (req, res) => {
    const { id_cv } = req.params;
    const { datos_personales, experiencia_laboral, formacion_academica, habilidades, ubicacion, telefono } = req.body;
    
    try {
        const result = await pool.query(`
            UPDATE cv 
            SET datos_personales = COALESCE($1, datos_personales),
                experiencia_laboral = COALESCE($2, experiencia_laboral),
                formacion_academica = COALESCE($3, formacion_academica),
                habilidades = COALESCE($4, habilidades),
                ubicacion = COALESCE($5, ubicacion),
                telefono = COALESCE($6, telefono),
                fecha_actualizacion = CURRENT_TIMESTAMP
            WHERE id_cv = $7
            RETURNING *
        `, [datos_personales, experiencia_laboral, formacion_academica, habilidades, ubicacion, telefono, id_cv]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'CV no encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const eliminarCV = async (req, res) => {
    const { id_cv } = req.params;
    
    try {
        const result = await pool.query(`
            DELETE FROM cv 
            WHERE id_cv = $1
            RETURNING *
        `, [id_cv]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'CV no encontrado' });
        }
        res.json({ message: 'CV eliminado exitosamente', cv: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

